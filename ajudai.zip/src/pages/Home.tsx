import React from "react";
import Header from "../components/Header";

const Home = () => {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Header */}
      <Header />

      {/* Conteúdo da Página */}
      <main className="flex-grow flex flex-col items-center justify-center">
        <h1 className="text-4xl font-bold text-blue-600 mb-4">
          Bem-vindo ao Ajudaí
        </h1>
        <p className="text-gray-700 text-lg mb-6 text-center">
          Conectando clientes e prestadores de serviços com rapidez e segurança.
        </p>
        <div className="flex gap-4">
          <button className="px-6 py-3 bg-blue-500 text-white rounded-lg shadow-md hover:bg-blue-700">
            Contratar Serviço
          </button>
          <button className="px-6 py-3 bg-green-500 text-white rounded-lg shadow-md hover:bg-green-700">
            Oferecer Serviço
          </button>
        </div>
      </main>

      {/* Footer Placeholder */}
      <footer className="bg-gray-800 text-white py-4 text-center">
        © 2024 Ajudaí - Todos os direitos reservados.
      </footer>
    </div>
  );
};

export default Home;
